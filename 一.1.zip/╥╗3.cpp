#include<iostream>
using namespace std;
int main()
{
	cout << "short length" << sizeof(short)<<endl;
	cout << "long length" << sizeof(long)<< endl;
	cout << "float length" << sizeof(float)<< endl;
	cout << "double length" << sizeof(double)<< endl;
	cout << "long double" << sizeof(long double)<< endl;
	cout << "wchar_t" << sizeof(wchar_t)<< endl;
	return 0;
}