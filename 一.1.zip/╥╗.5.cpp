#include<iostream>
using namespace std;

float wd(float a)
{
	float b = 32 + 1.8 * a;
		cout << b << endl;
		return b;
}
int main()
{
	float x;
	cin >> x;
	cout << wd(x);
	return 0;
}
