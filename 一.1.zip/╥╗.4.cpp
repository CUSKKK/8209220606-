#include <iostream> 
#include <iomanip> 
using namespace std;
int main()
{
unsigned int testUnint = 65534;
cout << "output in unsigned int	type:" << testUnint << endl;
cout << "output in short type:" << static_cast<short>(testUnint) << endl;	
cout << "output in double type:" << static_cast<double>(testUnint) << endl;
cout << "output in double type:" << setprecision(4) << static_cast<double>(testUnint) << endl;
cout << "output in Hex unsigned int type:" << hex << testUnint << endl;

cout << "output in Hex unsigned int type:" << oct<< testUnint << endl;
system("pause");
return 0;
}
