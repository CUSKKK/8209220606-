using namespace std;
#include <iostream>




float yztj(float x, float y)
{
    const float pai = 3.14;
    float z;
    z = 1.0 / (3.0)* x * x * pai * y;

    return z;
}
int main()
{
    float x, y;
    cin >> x >> y;
    cout << yztj(x, y) << endl;
    return yztj(x, y);
        
}