#include <iostream>
using namespace std;
int main()
{
	char a;
	cin>>a;
	if (a <= 'Z' && a >= 'A')
		cout <<a+1 << endl;
	else cout<<char(a-32)<<endl;
}