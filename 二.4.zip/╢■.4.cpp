#include<iostream>
using namespace std;
int main()
{
	cout << "a�ǵ�һ�����֣�b�ǵڶ������֣���Ҫ�����" << endl;
	int a, c;
	char b;
	cin >> a >> b >> c;
	switch (b)
	{
	case '+':
		cout << a + c << endl;
		break;
	case '-':
		cout << a - c << endl;
		break;
	case '*':
		cout << a * c<< endl;
		break;
	case '%':
		cout << a % c << endl;
		break;
	case '/':
		if (c == 0)
			cout << "error" << endl;
		else cout << a / c<< endl;
	default:
		cout <<"error" << endl;
     return 0;

	}



}
