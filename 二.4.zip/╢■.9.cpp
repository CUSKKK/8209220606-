#include<iostream>
using namespace std;
int main()
{


		float m = 0, i, j;
	for (i = 0, j = 2; j <= 100; j=j * 2)
		i++, m = m + j;
	cout << m / i *0.8<< endl;
	return 0;
}

