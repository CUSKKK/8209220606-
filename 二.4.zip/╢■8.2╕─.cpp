#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	double a, b, c;
	cout << "please input a number:";
	cin >> a;
	b = a;
	c = (b + a / b) / 2;
	if (a < 0)
	{
		cout << "error" << endl;
	}
	do
	{
		b = c;
		c = (b + a / b) / 2;
	} while (c - b > -0.000000000001 || c - b < 0.0000000000001);
	cout << "ƽ����Ϊ" << setprecision(11) << c << endl;
	return 0;
}
