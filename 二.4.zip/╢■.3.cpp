

#include<iostream>
using namespace std;

float zc(float x, float y, float z)
{
	float C = x + y + z;
	return C;
}
int main()
{
	float a, b, c;
	cin >> a >> b >> c;
	cout << zc(a, b, c) << "\t" << endl;

	if (a + b > c && a+c>b&&b+c>a)
	{
		if (a == b || a == c || b == c)
			cout << "this is a deng yao san jiao xing";
		else cout << "zhe bu shi deng yao san jiao xing" << endl;
	}
	else cout << "bu shi san jiao xing" << endl;
	return 0;
}

